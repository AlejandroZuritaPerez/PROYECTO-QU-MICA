/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elementquiz;

/**
 *
 * @author AMD A6
 */

public class EstructuraPregunta {
    public String pregunta;
    public String textOpcA;
    public String textOpcB;
    public String textOpcC;
    public String textOpcD;
    public String RespOk;
    
    
public EstructuraPregunta() {
    
                                                    
                    
}

}

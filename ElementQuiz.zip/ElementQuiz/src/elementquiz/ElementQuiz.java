package elementquiz;

/**
 *
 * @author ALEJANDRO ZURITA PÉREZ
 */
public class ElementQuiz {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}

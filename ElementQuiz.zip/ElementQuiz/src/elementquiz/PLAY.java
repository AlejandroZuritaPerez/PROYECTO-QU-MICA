/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package elementquiz;

import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.util.Random;

/**
 *
 * @author ALEJANDRO ZURITA PÉREZ
 */
public class PLAY extends javax.swing.JFrame {
    
    private EstructuraPregunta[] ListaPreg = new EstructuraPregunta[17];
    private int apuntador;
    private int nRespOk;
    
    /**
     * Creates new form PLAY
     */
    public PLAY() {
        initComponents();
        this.setLocationRelativeTo(null);
        apuntador = 0;
        nRespOk = 0;  
        iniciaLista();
        Siguente();
        
    }
    
   
    
    private void iniciaLista(){
        EstructuraPregunta pregunta1 = new EstructuraPregunta();
        
        pregunta1.pregunta = "1.- ¿Es un gas incoloro, inodoro y muy reactivo que se halla en todos los componentes de la materia viva y en muchos minerales, siendo el elemento más abundante en el universo?";
        pregunta1.textOpcA = "A)Oxigeno";
        pregunta1.textOpcB = "B)Hidrogeno";
        pregunta1.textOpcC = "C)Magnesio";
        pregunta1.textOpcD = "D)Radio";
        pregunta1.RespOk = "B)Hidrogeno";
        ListaPreg[1] = pregunta1;
        
        
        EstructuraPregunta pregunta2 = new EstructuraPregunta();        
        pregunta2.pregunta = "2.- ¿Elemento que es un gas venenoso y pesa un poco más que el aire?";
        pregunta2.textOpcA = "A)Aluminio";
        pregunta2.textOpcB = "B)Oxigeno ";
        pregunta2.textOpcC = "C)Flúor";
        pregunta2.textOpcD = "D)Estaño";
        pregunta2.RespOk = "C)Flúor";
        ListaPreg[2] = pregunta2;
        
        EstructuraPregunta pregunta3 = new EstructuraPregunta(); 
        pregunta3.pregunta = "3.- ¿Las partículas de este elemento generadas por las ciudades y la industria se disuelven por la contaminación del aire causada por el ser humano y se vierten en el mar, lo que potencialmente aumenta la cantidad de gases de efecto invernadero que pueden absorber los océanos del planeta?";
        pregunta3.textOpcA = "A)Zinc";
        pregunta3.textOpcB = "B)Níquel";
        pregunta3.textOpcC = "C)Cobalto";
        pregunta3.textOpcD = "D)Hierro";
        pregunta3.RespOk = "D)Hierro";
        ListaPreg[3] = pregunta3;
        
        EstructuraPregunta pregunta4 = new EstructuraPregunta();
        pregunta4.pregunta = "4.- Sus compuestos son considerados como altamente tóxicos y carcinógenos. Los compuestos del rodio manchan la piel fuertemente. Inflamable. ¿Posible explosión del polvo si se encuentra en forma de polvo o granular, mezclado con agua?";
        pregunta4.textOpcA = "A)Oxigeno";
        pregunta4.textOpcB = "B)Helio";
        pregunta4.textOpcC = "C)Rodio";
        pregunta4.textOpcD = "D)Hidrogeno";
        pregunta4.RespOk = "C)Rodio";
        ListaPreg[4] = pregunta4;
        
        EstructuraPregunta pregunta5 = new EstructuraPregunta();
        pregunta5.pregunta = "5.- ¿Este elemento genera contaminación y alteraciones en la calidad del agua, principalmente el incremento en la turbidez, por vertimiento de aguas residuales mineras que van contaminadas con mercurio y cianuro?";
        pregunta5.textOpcA = "A)Plata";
        pregunta5.textOpcB = "B)Platino";
        pregunta5.textOpcC = "C)Oro";
        pregunta5.textOpcD = "D)Hierro";
        pregunta5.RespOk = "C)Oro";
        ListaPreg[5] = pregunta5;
        
        EstructuraPregunta pregunta6 = new EstructuraPregunta();
        pregunta6.pregunta = "6.- Elemento que contamina el agua, aire y causa envenenamiento. Las algas lo absorben, luego los peces y finalmente el hombre. ¿Los granos lo retienen y finalmente el hombre los come?";
        pregunta6.textOpcA = "A)Hidrogeno";
        pregunta6.textOpcB = "B)Rodio";
        pregunta6.textOpcC = "C)Estaño";
        pregunta6.textOpcD = "D)Mercurio";
        pregunta6.RespOk = "D)Mercurio";
        ListaPreg[6] = pregunta6;
        
        EstructuraPregunta pregunta7 = new EstructuraPregunta();
        pregunta7.pregunta = "7.- ¿Su quema genera emisiones de CO2 (convirtiéndolo en el principal causante del cambio climático) y la minería subterránea, gas metano (un potente gas de efecto invernadero)?";
        pregunta7.textOpcA = "A)Helio";
        pregunta7.textOpcB = "B)Oro";
        pregunta7.textOpcC = "C)Carbono";
        pregunta7.textOpcD = "D)cobalto";
        pregunta7.RespOk = "C)Carbono";
        ListaPreg[7] = pregunta7;
        
        EstructuraPregunta pregunta8 = new EstructuraPregunta();
        pregunta8.pregunta = "8.- ¿Cuándo se combina con partículas o con la humedad del aire ya que se forma ácido sulfúrico, y produce lo que se conoce como lluvia ácida, provocando la destrucción de bosques, vida salvaje y la acidificación de las aguas superficiales?";
        pregunta8.textOpcA = "A)Litio";
        pregunta8.textOpcB = "B)Azufre";
        pregunta8.textOpcC = "C)Cloro";
        pregunta8.textOpcD = "D)Estaño";
        pregunta8.RespOk = "B)Azufre";
        ListaPreg[8] = pregunta8;
        
        EstructuraPregunta pregunta9 = new EstructuraPregunta();
        pregunta9.pregunta = "9.- ¿La exposición repetida a este elemento en el aire puede afectar al sistema inmunitario, la sangre, el corazón, y el sistema respiratorio de los animales?";
        pregunta9.textOpcA = "A)Oxigeno";
        pregunta9.textOpcB = "B)Cloro";
        pregunta9.textOpcC = "C)helio";
        pregunta9.textOpcD = "D)indio";
        pregunta9.RespOk = "B)Cloro";
        ListaPreg[9] = pregunta9;
        
        EstructuraPregunta pregunta10 = new EstructuraPregunta();
        pregunta10.pregunta = "10.- ¿Un metal superpesado y radiactivo es una de las sustancias más tóxicas para la salud humana, y el riesgo de exposición se incrementa como resultado de la contaminación del suelo, el aire o el agua tras un escape o accidente radiactivo?";
        pregunta10.textOpcA = "A)Mercurio";
        pregunta10.textOpcB = "B)Radio";
        pregunta10.textOpcC = "C)Plutonio";
        pregunta10.textOpcD = "D)uranio";
        pregunta10.RespOk = "C)Plutonio";
        ListaPreg[10] = pregunta10;
        
        EstructuraPregunta pregunta11 = new EstructuraPregunta();
        pregunta11.pregunta = "11.- ¿Puede dar efectos químicos después de la toma de grandes cantidades de uranio y estos pueden provocar efectos tales como enfermedades del hígado?";
        pregunta11.textOpcA = "A)Mercurio";
        pregunta11.textOpcB = "B)Uranio";
        pregunta11.textOpcC = "C)Radio";
        pregunta11.textOpcD = "D)plutonio";
        pregunta11.RespOk = "B)Uranio";
        ListaPreg[11] = pregunta11;
        
        EstructuraPregunta pregunta12 = new EstructuraPregunta();
        pregunta12.pregunta = "12.- Es una sustancia química radiactiva formada de la degradación del uranio y el torio. ¿La exposición a niveles altos de radio produce un aumento en la tasa de cáncer de los huesos, el hígado y los senos?";
        pregunta12.textOpcA = "A)uranio";
        pregunta12.textOpcB = "B)Plutonio";
        pregunta12.textOpcC = "C)Estaño";
        pregunta12.textOpcD = "D)Radio";
        pregunta12.RespOk = "D)Radio";
        ListaPreg[12] = pregunta12;
        
        EstructuraPregunta pregunta13 = new EstructuraPregunta();
        pregunta13.pregunta = "13.- ¿Se acumula en el cuerpo conforme se inhala del aire o se ingiere con los alimentos y el agua proviene de las gasolinas para automóviles, pues se requiere para proporcionarle propiedades antidetonantes?";
        pregunta13.textOpcA = "A)Radio";
        pregunta13.textOpcB = "B)Plomo";
        pregunta13.textOpcC = "C)Estaño";
        pregunta13.textOpcD = "D)indio";
        pregunta13.RespOk = "B)Plomo";
        ListaPreg[13] = pregunta13;
        
        EstructuraPregunta pregunta14 = new EstructuraPregunta();
        pregunta14.pregunta = "14.- ¿Su nombre proviene del planeta?";
        pregunta14.textOpcA = "A)Neptunio";
        pregunta14.textOpcB = "B)Kriptón";
        pregunta14.textOpcC = "C)Radón";
        pregunta14.textOpcD = "D)Rutherfordio";
        pregunta14.RespOk = "A)Neptunio";
        ListaPreg[14] = pregunta14;
        
        EstructuraPregunta pregunta15 = new EstructuraPregunta();
        pregunta15.pregunta = "15.- ¿Sus vapores contaminan el aire, además sus compuestos derivados son lacrimógenos y venenosos?";
        pregunta15.textOpcA = "A)Galio";
        pregunta15.textOpcB = "B)Cobre";
        pregunta15.textOpcC = "C)Telurio";
        pregunta15.textOpcD = "D)Bromo";
        pregunta15.RespOk = "D)Bromo";
        ListaPreg[15] = pregunta15;
        
        EstructuraPregunta pregunta16 = new EstructuraPregunta();
        pregunta16.pregunta = "";
        pregunta16.textOpcA = "";
        pregunta16.textOpcB = "";
        pregunta16.textOpcC = "";
        pregunta16.textOpcD = "";
        pregunta16.RespOk = "";
        ListaPreg[16] = pregunta16;

        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
                
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        opcGroup = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        pregArea = new javax.swing.JTextArea();
        opcA = new javax.swing.JRadioButton();
        opcB = new javax.swing.JRadioButton();
        opcC = new javax.swing.JRadioButton();
        opcD = new javax.swing.JRadioButton();
        siguente = new javax.swing.JButton();
        calificar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        opc = new javax.swing.JMenu();
        exit = new javax.swing.JCheckBoxMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        regresar = new javax.swing.JCheckBoxMenuItem();

        jMenu1.setText("File");
        jMenuBar2.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar2.add(jMenu2);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));

        pregArea.setColumns(20);
        pregArea.setLineWrap(true);
        pregArea.setRows(5);
        jScrollPane1.setViewportView(pregArea);

        opcGroup.add(opcA);
        opcA.setText("A) ");
        opcA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcAActionPerformed(evt);
            }
        });

        opcGroup.add(opcB);
        opcB.setText("B) ");
        opcB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcBActionPerformed(evt);
            }
        });

        opcGroup.add(opcC);
        opcC.setText("C) ");

        opcGroup.add(opcD);
        opcD.setText("D) ");

        siguente.setText("Siguente");
        siguente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                siguenteActionPerformed(evt);
            }
        });

        calificar.setText("Calificar");
        calificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(calificar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(siguente))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(opcA)
                            .addComponent(opcB))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(opcC)
                            .addComponent(opcD))))
                .addGap(94, 94, 94))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(opcA)
                    .addComponent(opcC))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(opcB)
                    .addComponent(opcD))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(siguente)
                    .addComponent(calificar))
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 390));

        jMenuBar1.setBackground(new java.awt.Color(153, 102, 255));

        opc.setText("OPCIONES");

        exit.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.ALT_DOWN_MASK | java.awt.event.InputEvent.CTRL_DOWN_MASK));
        exit.setSelected(true);
        exit.setText("EXIT");
        exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar 25x25.jpg"))); // NOI18N
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        opc.add(exit);
        opc.add(jSeparator1);

        regresar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.ALT_DOWN_MASK | java.awt.event.InputEvent.CTRL_DOWN_MASK));
        regresar.setSelected(true);
        regresar.setText("Return Page");
        regresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/regresar 25x25.jpg"))); // NOI18N
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });
        opc.add(regresar);

        jMenuBar1.add(opc);

        setJMenuBar(jMenuBar1);
        jMenuBar1.getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        if (JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to exit the Application?",
                "ElementQuiz", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE) == JOptionPane.YES_OPTION)
        {System.exit(0);
        }
        else{
                setDefaultCloseOperation(0);
        }
    }//GEN-LAST:event_exitActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        MENU m = new MENU();
        m.setVisible(true);
    }//GEN-LAST:event_regresarActionPerformed

    private void opcAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opcAActionPerformed

    private void opcBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opcBActionPerformed

    private void calificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calificarActionPerformed
        if (nRespOk == 15){
                    JOptionPane.showMessageDialog(null, "10", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 14) {
                    JOptionPane.showMessageDialog(null, "9.3", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 13) {
                    JOptionPane.showMessageDialog(null, "8.6", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 12) {
                    JOptionPane.showMessageDialog(null, "8", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 11) {
                    JOptionPane.showMessageDialog(null, "7.3", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 10) {
                    JOptionPane.showMessageDialog(null, "6.6", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 9) {
                    JOptionPane.showMessageDialog(null, "6", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 8) {
                    JOptionPane.showMessageDialog(null, "5.3", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 7) {
                    JOptionPane.showMessageDialog(null, "4.6", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 6) {
                    JOptionPane.showMessageDialog(null, "4", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 5) {
                    JOptionPane.showMessageDialog(null, "3.3", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 4) {
                    JOptionPane.showMessageDialog(null, "2.6", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 3) {
                    JOptionPane.showMessageDialog(null, "2", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 2) {
                    JOptionPane.showMessageDialog(null, "1.3", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 1) {
                    JOptionPane.showMessageDialog(null, "0.6", "CALIFICACIÓN", HEIGHT);
                } if (nRespOk == 0) {
                    JOptionPane.showMessageDialog(null, "0", "CALIFICACIÓN", HEIGHT);
                }
                
        JOptionPane.showMessageDialog(null, "Tu puntaje es: " + nRespOk + " de 15", "SCORE", HEIGHT); 
        
    }//GEN-LAST:event_calificarActionPerformed

    private void Siguente (){
        
        String strSelect = "";
        EstructuraPregunta nodo;
        
                if (apuntador == 15){
                    siguente.setEnabled(false);
        }
        
        
        if (apuntador > 0){
            
            if (opcA.isSelected()) {
                strSelect = opcA.getText();
            }
            if (opcB.isSelected()) {
                strSelect = opcB.getText();
            }
            if (opcC.isSelected()) {
                strSelect = opcC.getText();
            }
            if (opcD.isSelected()) {
                strSelect = opcD.getText();
            }
            
            //JOptionPane.showMessageDialog(null, strSelect, "", HEIGHT);
            nodo = ListaPreg[apuntador];
 
            
            if (strSelect.equals(nodo.RespOk)) {
                nRespOk++;
            }
        }
        
        apuntador++;
        
        nodo = ListaPreg[apuntador];
        
        
        
        pregArea.setText(nodo.pregunta); 
        opcA.setText(nodo.textOpcA);
        opcB.setText(nodo.textOpcB);
        opcC.setText(nodo.textOpcC);
        opcD.setText(nodo.textOpcD);
        
                if (apuntador > 15){
                    pregArea.setVisible(false);
                    opcA.setVisible(false);
                    opcB.setVisible(false);
                    opcC.setVisible(false);
                    opcD.setVisible(false);
                    JOptionPane.showMessageDialog(null, "Fin del Juego. Tu puntaje final es: " + nRespOk + " de 15", "SCORE", HEIGHT);
                    
        }
                
        
    }
    
    private void siguenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_siguenteActionPerformed
       Siguente();
       
    }//GEN-LAST:event_siguenteActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PLAY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PLAY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PLAY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PLAY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PLAY().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton calificar;
    private javax.swing.JCheckBoxMenuItem exit;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JMenu opc;
    private javax.swing.JRadioButton opcA;
    private javax.swing.JRadioButton opcB;
    private javax.swing.JRadioButton opcC;
    private javax.swing.JRadioButton opcD;
    private javax.swing.ButtonGroup opcGroup;
    private javax.swing.JTextArea pregArea;
    private javax.swing.JCheckBoxMenuItem regresar;
    private javax.swing.JButton siguente;
    // End of variables declaration//GEN-END:variables
}
